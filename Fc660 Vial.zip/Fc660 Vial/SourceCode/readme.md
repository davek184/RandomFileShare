# fc660c_rgb
Modified FC660C QMK firmware to support RGB Underglow.

See fc660c/README.md for changelog.
