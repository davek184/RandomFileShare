/* SPDX-License-Identifier: GPL-2.0-or-later */

#pragma once

#define VIAL_KEYBOARD_UID {0x93, 0x68, 0xA5, 0xAE, 0x06, 0xD3, 0x10, 0xF1}
#define DYNAMIC_KEYMAP_LAYER_COUNT 3
#define VIAL_COMBO_ENTRIES 3
#define VIAL_TAP_DANCE_ENTRIES 4