# The default keymap for the FC660C

Emulates original keymap.

![](https://i.imgur.com/fg89nez.jpg)