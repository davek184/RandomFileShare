#pragma once

#define RETRO_TAPPING
