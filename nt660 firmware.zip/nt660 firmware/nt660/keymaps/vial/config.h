/* SPDX-License-Identifier: GPL-2.0-or-later */

#pragma once

#define VIAL_KEYBOARD_UID {0x90, 0x1C, 0x15, 0x9C, 0x60, 0xFD, 0x3E, 0xB8}
#define DYNAMIC_KEYMAP_LAYER_COUNT 2
#define VIAL_COMBO_ENTRIES 2
#define VIAL_TAP_DANCE_ENTRIES 1
